package com.elib.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.elib.model.User;
import com.elib.repo.ElibJPARepository;

@RestController
public class UserController {
	@Autowired
	private ElibJPARepository userRepository;

	@GetMapping("user")
	private List<User> getuserDetail() {
		List<User> findAll = userRepository.findAll();
		System.out.println(findAll);
		return findAll;
	}
	
	@PostMapping("setUser")
	User setUser(@RequestBody User user){
		User save = userRepository.save(user);
		return save;
		
	}

}
