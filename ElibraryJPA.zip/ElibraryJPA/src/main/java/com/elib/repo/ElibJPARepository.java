package com.elib.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elib.model.User;

public interface ElibJPARepository extends JpaRepository<User, Integer> {
}
