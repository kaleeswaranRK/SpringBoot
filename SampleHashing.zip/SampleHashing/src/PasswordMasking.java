//
//import org.apache.logging.log4j.core.LogEvent;
//
//import org.apache.logging.log4j.core.config.plugins.Plugin;
//
//import org.apache.logging.log4j.core.pattern.ConverterKeys;
//
//import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
//
//@Plugin(name = "logmask", category = "Converter")
//@ConverterKeys({ "m" })
//public class PasswordMasking extends LogEventPatternConverter {
//
//	public PasswordMasking(String[] options) {
//
//		super("m", "m");
//
//	}
//
//	public static PasswordMasking newInstance(final String[] options) {
//
//		return new PasswordMasking(options);
//
//	}
//
//	@Override
//	public void format(LogEvent logEvent, StringBuilder outputMsg) {
//
//		String message = logEvent.getMessage().getFormat();
//
//		String REGEX_PLAIN_TEXT = "([0-9]{6})[0-9]{0,9}([0-9]{4})";
//
//		outputMsg.append(message.replaceAll(REGEX_PLAIN_TEXT, "XXXX XXXX XXXX XXXX"));
//
//	}
//
//}




/*	logger.info("plainText : " + plainText.substring(0,4)+plainText.substring(4, plainText.length()).replaceAll(".", "*")+" Encrypted value : "+cipher);
*/