import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonAssign {
	public static void main(String[] args) throws IOException {

		FileReader fr = new FileReader("C:\\Users\\ADMIN\\Desktop\\SampleInput.txt");
		//folderName(fr);
		fileName(fr);
	}

	private static void folderName(FileReader fr) throws JSONException, IOException {
		JSONArray js = new JSONArray();
		BufferedReader br = new BufferedReader(fr);
		String line;
		while ((line = br.readLine()) != null) {
			JSONObject prop = new JSONObject();
			prop.put("filePath", line);
			String[] split = line.split("/");
			prop.put("applicationName", split[split.length - 2]);
			js.put(prop);
		}
		System.out.println(js);
		System.out.println(js.length());
	}
	private static void fileName(FileReader fr) throws JSONException, IOException  {
		JSONArray js = new JSONArray();
		BufferedReader br = new BufferedReader(fr);
		String line;
		while ((line = br.readLine()) != null) {
			JSONObject prop = new JSONObject();
			prop.put("filePath", line);
			String[] split = line.split("/");
			prop.put("applicationName", split[split.length - 1].replaceAll(".xml", ""));
			js.put(prop);
		}
		System.out.println(js);
		System.out.println(js.length());

	}
}
