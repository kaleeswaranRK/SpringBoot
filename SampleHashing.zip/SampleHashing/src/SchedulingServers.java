import org.json.JSONArray;

public class SchedulingServers {
	public static void main(String[] args) {
		JSONArray js1 = new JSONArray();
		js1.put(0,"one");
		js1.put(1,"two");
		js1.put(2,"three");
		js1.put(3,"four");
		js1.put(4,"five");
		System.out.println("js1 : "+js1);
		JSONArray js2 = new JSONArray();
		js2.put(0,"one");
		js2.put(1,"two");
		js2.put(2,"three");
		js2.put(3,"four");
		js2.put(4,"five");
		System.out.println("js2 : "+js2);
		js1.putAll(js2);
		System.out.println("js1 : "+js1);
	}

}
