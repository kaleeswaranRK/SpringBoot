import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class Cryptograpy {	

	protected String secretKey = "6gU7jxGdRGDJcisOR435feEvyF57JzDSfgLonlMQkFvZc9Yi0bs0dYzNnR3EZpPqjVPJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4Afi/VPt6a7JTK2o0I42RcBgGQO8DGHt76wXkd+PxxZZPA5YaLPlhXjL70Wdlnqc2Sd+xx0kzcDxTzRedx4VpIe8tEy1sKqFfDfHSZj4qic=";
	protected String salt = "A3k#Gvb6@CB#tv$50p!50c35onsM!";

	private String encrypt(String strToEncrypt, String secret) {
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	private String decrypt(String strToDecrypt, String secret) {
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			String temp = new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
			String returnValue = temp.substring(16, temp.length() - 1);
			return returnValue.substring(0, returnValue.length() - 15);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public String getPlainText(String cipher) {
		Cryptograpy security = new Cryptograpy();
		if (cipher != null && cipher.trim().length() > 0) {
			return security.decrypt(cipher, secretKey);
		} else {
			return null;
		}
	}

	public String getCipher(String plainText) {
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		Cryptograpy security = new Cryptograpy();
		return security.encrypt(uuid.substring(0, 16).concat(plainText).concat(uuid.substring(16, 32)), secretKey);
	}
	public static void main(String[] args) {
		String cipher = new Cryptograpy().getCipher("");
//		System.out.println(cipher);
		System.out.println(new Cryptograpy().getPlainText("4Kn279FnJo9bBywZodD8GZ7CiTPZBtvqocPKwZYTleIH2LO3KhYECDQm98xLFErnDjMpS+sfmUl7pm95YEBFmoe6/amCTZT3bgoGox+kbEE+0iad3UibHf2C9wO+vS9jDx939awPckf98lk0tAW9u1UN2Z1UHxR8NFhKp331wuAcusPoOnWch7XZW2KV+odM"));
//		System.out.println(new Cryptograpy().getPlainText("O81YghQqJst0q+bm5s0k+brLzj7fZFFYxeT1YzSV9t43BZjA6XYzYTvPTVcWKQTUZgxmb5o3XpaX0z4UEWXEjlaZAI88k4oNq+xOKVJ1utOo8W3r5vL4dMya+BrVXcnO0OnCovHRnET/LzJblGzWdiOt7wG37BEuEGTI1d/DhMwP5vLoLI2nL4zGp5hnT337+4rMV+D/Hnoa0eBZ1+uLpA0UnhSalIYYV/56v19O6/c="));
	}
}
