import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

import com.elib.model.TaskServerList;
import com.elib.model.serverList;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ScheduleServercheck {
	long startTime;
	JSONArray schedulerArray;
	int startingLength;
	long filemodified;

	ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);
	Map<String, Runnable> taskMap = new LinkedHashMap<>();
	TaskServerList taskServer = new TaskServerList();
	static ScheduleServercheck scheduler = new ScheduleServercheck();

	public static void main(String[] args)
			throws StreamReadException, DatabindException, IOException, InterruptedException, ExecutionException {
		String filepath = "C:\\Users\\ADMIN\\Desktop\\ServerList.json";
		scheduler.schedulerStart(filepath);
//		ScheduledFuture<?> scheduleAtFixedRate = exec.scheduleAtFixedRate(new Runnable() {
//			public void run() {
//				System.out.println(0 + " time :1st " + 1000 / 1000);
//			}
//		}, 0, 2, TimeUnit.SECONDS);
//		System.out.println("1 : " + scheduleAtFixedRate.toString());
//		ScheduledFuture<?> scheduleAtFixedRate2 = exec.scheduleAtFixedRate(new Runnable() {
//			public void run() {
//				System.out.println(0 + " time :2nd " + 1000 / 1000);
//			}
//		}, 0, 2, TimeUnit.SECONDS);
	}

	private void schedulerStart(String filepath) throws StreamReadException, DatabindException, IOException {

		File file = new File(filepath);
		if (file.isFile()) {
			schedulerArray = jsonFileReader(filepath);
			if (schedulerArray != null && schedulerArray.length() > 0) {
				startTime = System.currentTimeMillis();
				startingLength = schedulerArray.length();
				filemodified = new File(filepath).lastModified();
				scheduler.schedulerMethod(filepath);
				for (int i = 0; i < schedulerArray.length(); i++) {
					JSONObject serverjs = schedulerArray.getJSONObject(i);
					scheduler.ScheduleMethodwithTime(serverjs.getInt("scheduleTime"), serverjs.getString("serverName"),
							serverjs.getString("timeFormat"));
				}
			} else {
				System.out.println("JsonReader returns null value");
			}

		} else {
			System.out.println("No file Available");
		}
	}

	public void reschedulerStart(String filepath) throws StreamReadException, DatabindException, IOException {
		try {
			long lastModified = new File(filepath).lastModified();
			if (lastModified != filemodified) {
				JSONArray schedulerArrayNew = jsonFileReader(filepath);

				int currentLength = schedulerArrayNew.length();
				if (startingLength <= currentLength) {
					List<String> jslist = new ArrayList<>();
					for (int i = 0; i < schedulerArray.length(); i++) {
						jslist.add(schedulerArray.getJSONObject(i).toString());
					}
					System.out.println(jslist);
					for (int i = 0; i < schedulerArrayNew.length(); i++) {
						if (!jslist.contains(schedulerArrayNew.getJSONObject(i).toString())) {
							System.out.println(schedulerArrayNew.getJSONObject(i).toString());
							scheduler.ScheduleMethodwithTime(schedulerArrayNew.getJSONObject(i).getInt("scheduleTime"),
									schedulerArrayNew.getJSONObject(i).getString("serverName"),
									schedulerArrayNew.getJSONObject(i).getString("timeFormat"));
						}
					}
					schedulerArray = schedulerArrayNew;
					startingLength = schedulerArray.length();
					filemodified = lastModified;
				} else if (startingLength > currentLength) {
					List<String> jslist = new ArrayList<>();
					for (int i = 0; i < schedulerArrayNew.length(); i++) {
						jslist.add(schedulerArrayNew.getJSONObject(i).toString());
					}
					System.out.println(schedulerArray);
					for (int i = 0; i < schedulerArray.length(); i++) {
						if (!jslist.contains(schedulerArray.getJSONObject(i).toString())) {
							System.out.println(schedulerArray.getJSONObject(i).toString());
							exec.remove(taskMap.get(schedulerArray.getJSONObject(i).get("serverName")));
						}
					}
					schedulerArray = schedulerArrayNew;
					startingLength = schedulerArrayNew.length();
					filemodified = lastModified;
				}

			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void schedulerMethod(String filepath) {
		Timer t = new Timer();
		t.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				try {
					reschedulerStart(filepath);
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}, 0, 1000);
	}

	private void taskMethod(String taskname, long timeInterval) {
		System.out.println(taskname + " time :" + timeInterval / 1000);
	}

	private void ScheduleMethodwithTime(int time, String output, String timeFormat) {
		if (timeFormat.equalsIgnoreCase("seconds")) {
			ScheduledFuture<?> Task = exec.scheduleAtFixedRate(new Runnable() {
				public void run() {
					long timeInterval = System.currentTimeMillis() - startTime;
					taskMethod(output, timeInterval);
				}
			}, 0, time, TimeUnit.SECONDS);
			taskMap.put(output, (Runnable) Task);
		} else if (timeFormat.equalsIgnoreCase("Minutes")) {
			ScheduledFuture<?> Task = exec.scheduleAtFixedRate(new Runnable() {

				public void run() {
					long timeInterval = System.currentTimeMillis() - startTime;
					System.out.println(output + " time :" + timeInterval / 1000);
				}
			}, 0, time, TimeUnit.MINUTES);
			taskMap.put(output, (Runnable) Task);
		} else if (timeFormat.equalsIgnoreCase("Hours")) {
			ScheduledFuture<?> Task = exec.scheduleAtFixedRate(new Runnable() {
				public void run() {
					long timeInterval = System.currentTimeMillis() - startTime;
					System.out.println(output + " time :" + timeInterval / 1000);
				}
			}, 0, time, TimeUnit.HOURS);
			taskMap.put(output, (Runnable) Task);
		} else if (timeFormat.equalsIgnoreCase("Days"))

		{
			ScheduledFuture<?> Task = exec.scheduleAtFixedRate(new Runnable() {
				public void run() {
					long timeInterval = System.currentTimeMillis() - startTime;
					System.out.println(output + " time :" + timeInterval / 1000);
				}
			}, 0, time, TimeUnit.DAYS);
			taskMap.put(output, (Runnable) Task);
		}
	}

	private JSONArray jsonFileReader(String filepath) throws StreamReadException, DatabindException, IOException {
		try {
			ObjectMapper mapper = new ObjectMapper();
			serverList[] readValue = mapper.readValue(Paths.get(filepath).toFile(), serverList[].class);
			return new JSONArray(readValue);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}
}
