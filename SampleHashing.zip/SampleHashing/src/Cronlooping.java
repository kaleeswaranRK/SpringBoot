import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import org.json.JSONArray;
import org.json.JSONObject;

import com.elib.model.serverList;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Cronlooping {

	long startTime;
	JSONArray InputData;
	int startingLength;
	long filemodified;

	public static void main(String[] args)
			throws StreamReadException, DatabindException, IOException, InterruptedException {
//		String filepath = "C:\\Users\\ADMIN\\Desktop\\ServerList.txt";
//		new Cronlooping().cronSplit(filepath);
//		long time = System.currentTimeMillis();
//		Thread.sleep(3000);
//		long endtime = System.currentTimeMillis();
//		System.out.println((endtime - time)/1000);
		new Cronlooping().cronProcess("server 1", 2);
	}

	private void cronSplit(String cronValue) throws StreamReadException, DatabindException, IOException {
		startTime = System.currentTimeMillis();
		JSONArray InputData = jsonFileReader(cronValue);
		startingLength = InputData.length();
		filemodified = new File(cronValue).lastModified();
		if (filemodified == new File(cronValue).lastModified()) {
			for (int i = 0; i < InputData.length(); i++) {
				JSONObject jsonObject = InputData.getJSONObject(i);
				cronProcess(jsonObject.getString("serverName"), jsonObject.getInt("scheduleTime"));
			}
		} else {

		}
	}

	private void cronProcess(String serverName, int serverTime) {
		while (true) {
			long endtime = System.currentTimeMillis();
				switch (serverName) {
				case "server 1":
					System.out.println("execute method 1 : " + endtime / 1000);
					break;
				case "server 2":
					System.out.println("execute method 2");
					break;
				}
		}

	}

	private void sleepTimer(int serverTime) {
		try {
			Thread.sleep(serverTime * 1000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

	}

	private static JSONArray jsonFileReader(String filepath)
			throws StreamReadException, DatabindException, IOException {
		try {
			ObjectMapper mapper = new ObjectMapper();
			serverList[] readValue = mapper.readValue(Paths.get(filepath).toFile(), serverList[].class);
			return new JSONArray(readValue);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}
}
