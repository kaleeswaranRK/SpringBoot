package com.scheduletask;

import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class JobTwo implements Job{
	
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		JobDetail jobDetail = arg0.getJobDetail();
		System.out.println("JOB 2 server : " + jobDetail.getKey());
	}
}
