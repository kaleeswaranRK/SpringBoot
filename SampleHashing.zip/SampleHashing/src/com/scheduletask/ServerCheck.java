package com.scheduletask;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerContext;
import org.quartz.SchedulerException;

public class ServerCheck implements Job {
	static long startTime = System.currentTimeMillis();

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		try {
			long endtime = System.currentTimeMillis();
			long value = endtime - startTime;
			SchedulerContext context = arg0.getScheduler().getContext();
			String key = arg0.getJobDetail().getKey().toString().replace("DEFAULT.", "");
			JSONObject name = (JSONObject) context.get(key);
			System.out.println(name.getString("methodName")+"-----"+key + " : " + " Time : " + (value / 1000));
			JSONObject applicationHealthStatus = getApplicationHealthStatus(name);
			applicationHealthStatus.put("serverName", key);
			//System.out.println(name.getString("methodName")+"--------------------"+applicationHealthStatus);
		} catch (SchedulerException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public JSONObject getApplicationHealthStatus(JSONObject serverDetails) {
		JSONObject result = new JSONObject();
		long startTime = System.currentTimeMillis();
		boolean success = false;
		int responseCode = 0;
		String responseMessage = "Not Connected";
		try {
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(null, new TrustManager[] { new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] chain, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] chain, String authType) {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}
			} }, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);

			URL url = new URL(serverDetails.getString("endpoint"));
			int connectTimeout = 3000;
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(connectTimeout);
			int readTimeout = 6000;
			con.setReadTimeout(readTimeout);
			con.setRequestMethod("GET");
			responseCode = con.getResponseCode();
			success = (con.getResponseCode() >= 200 && con.getResponseCode() < 300);
			responseMessage = success ? "Connected"
					: con.getResponseMessage() != null ? con.getResponseMessage() : "Not Connected";
		} catch (SocketTimeoutException e) {
			System.out.println(e);
			responseMessage = "Connection timed out";
		} catch (IOException e) {
			System.out.println(e);
			String errorMessage = e.getMessage();
			if (errorMessage.contains("Connection refused")) {
				responseMessage = "Connection refused";
			} else {
				responseMessage = e.getMessage();
			}
		} catch (Exception e) {
			System.out.println(e);
			responseMessage = e.getMessage();
		} finally {
			result.put("message", responseMessage);
			result.put("responseTime", System.currentTimeMillis() - startTime);
			result.put("responseCode", responseCode);
			result.put("status", (success ? "Online" : "Offline"));
		}
		return result;
	}

}
