package com.scheduletask;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SampleTest {
	static JSONArray s = new JSONArray();

	public static void main(String[] args) throws JSONException {
		try {
			String jsonArrStr = "[\n" + "\n" + "{\n" + "\"promptFormat\":\"wav\",\n" + "\"prompt\":\"1000.wav\",\n"
					+ "\"sequence\":\"1\"\n" + "},\n" + "{\n" + "\"promptFormat\":\"text\",\n" + "\"prompt\":\"5\",\n"
					+ "\"sequence\":\"4\"\n" + "},\n" + "{\n" + "\"promptFormat\":\"wav\",\n"
					+ "\"prompt\":\"1002.wav\",\n" + "\"sequence\":\"5\"\n" + "},\n" + "{\n"
					+ "\"promptFormat\":\"text\",\n" + "\"prompt\":\"1000\",\n" + "\"sequence\":\"2\"\n" + "},\n"
					+ "{\n" + "\"promptFormat\":\"wav\",\n" + "\"prompt\":\"1001.wav\",\n" + "\"sequence\":\"3\"\n"
					+ "}\n" + "\n" + "]";

			JSONArray jsonArr = new JSONArray(jsonArrStr);
			JSONArray sortedJsonArray = new JSONArray();

			List<JSONObject> jsonValues = new ArrayList<JSONObject>();
			for (int i = 0; i < jsonArr.length(); i++) {
				jsonValues.add(jsonArr.getJSONObject(i));
			}
			Collections.sort(jsonValues, new Comparator<JSONObject>() {

				private String KEY_NAME = "sequence";

				@Override
				public int compare(JSONObject a, JSONObject b) {
					String valA = new String();
					String valB = new String();

					try {
						valA = (String) a.get(KEY_NAME);
						valB = (String) b.get(KEY_NAME);

					} catch (JSONException e) {
						// do something
					}

					return valA.compareTo(valB);

				}
			});

			for (int i = 0; i < jsonArr.length(); i++) {
				sortedJsonArray.put(jsonValues.get(i));
			}

			System.out.println("Sorted JSON Array with Name: " + sortedJsonArray);

			s = sortedJsonArray;
			System.out.println(s);
			menu1();
		} catch (JSONException a) {
			a.printStackTrace();
		}
		// return sortedJsonArray;
	}

	public static ArrayList<String> menu1() throws JSONException {

		String dtmf = "3";

		ArrayList<String> prompt = new ArrayList<String>();

		// JSONArray json;
		try {
			// JSONArray json = new JSONArray(s);
			for (int i = 0; i < s.length(); i++) {
				// JSONObject JSONObject = new JSONObject(json.get(i).toString());
				JSONObject JSONObject = new JSONObject(s.get(i).toString());
				String sequence = JSONObject.get("sequence").toString();
				if (sequence.equals(dtmf)) {
					String currentPrompt = JSONObject.get("prompt").toString();
					String currentPromptFormat = JSONObject.get("promptFormat").toString();
					prompt.add(sequence);
					prompt.add(currentPrompt);
					prompt.add(currentPromptFormat);
					System.out.println(sequence);
					System.out.println(currentPrompt);
					System.out.println(currentPromptFormat);
					System.out.println(prompt);
				}

				// int sequence = Integer.parseInt(JSONObject.get("sequence").toString());

				// System.out.println(prompt);

			}

			// int indexOf = myNumbers.indexOf(dtmf);

			// System.out.println(dtmf); System.out.println(prompt.get(indexOf));
			// System.out.println(promptFormat.get(indexOf));

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return prompt;

	}
}
