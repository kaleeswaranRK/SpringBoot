package com.scheduletask;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.elib.model.TaskServerList;
import com.elib.model.serverList;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TaskExecuteClass {
	private static Scheduler scheduler;
	private static String filePath = "C:\\Users\\ADMIN\\Desktop\\ServerList.json";
	static JSONArray jsonFileReader;
	static int startingLength;
	static long filemodified;
	TaskServerList taskServer = new TaskServerList();

	public static void main(String[] args) throws Exception {
		try {
			scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.start();
			new TaskExecuteClass().createTask();
		} catch (Exception e) {
			scheduler.shutdown();
		}
	}

	public void reschedulerStart() throws StreamReadException, DatabindException, IOException {
		try {
//			System.out.println("reschedule Entry");
			long lastModified = new File(filePath).lastModified();
			if (lastModified != filemodified) {
				JSONArray jsonFileReaderNew = jsonFileReader(filePath);
				int currentLength = jsonFileReaderNew.length();
				if (startingLength <= currentLength) {
					List<String> jslist = new ArrayList<>();
					for (int i = 0; i < jsonFileReader.length(); i++) {
						jslist.add(jsonFileReader.getJSONObject(i).toString());
					}
					for (int i = 0; i < jsonFileReaderNew.length(); i++) {
						if (!jslist.contains(jsonFileReaderNew.getJSONObject(i).toString())) {
							System.out.println("Job Added : " + jsonFileReaderNew.getJSONObject(i).toString());
							startTask(jsonFileReaderNew.getJSONObject(i));
						}
					}
					jsonFileReader = jsonFileReaderNew;
					startingLength = jsonFileReader.length();
					filemodified = lastModified;
				} else {
					System.out.println("else");
					List<String> jslist = new ArrayList<>();
					for (int i = 0; i < jsonFileReaderNew.length(); i++) {
						jslist.add(jsonFileReaderNew.getJSONObject(i).toString());
					}
					for (int i = 0; i < jsonFileReader.length(); i++) {
						if (!jslist.contains(jsonFileReader.getJSONObject(i).toString())) {
							System.out.println("Job Removed : " + jsonFileReader.getJSONObject(i).toString());
							stopSchedularJob(jsonFileReader.getJSONObject(i).getString("serverName"));
						}
					}
					jsonFileReader = jsonFileReaderNew;
					startingLength = jsonFileReaderNew.length();
					filemodified = lastModified;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void createTask() {
		jsonFileReader = jsonFileReader(filePath);
		startingLength = jsonFileReader.length();
		filemodified = new File(filePath).lastModified();
		for (int i = 0; i < jsonFileReader.length(); i++) {
			startTask(jsonFileReader.getJSONObject(i));
		}
		reschedulerCreate();
	}

	private JSONArray jsonFileReader(String filePath) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			serverList[] readValue = mapper.readValue(Paths.get(filePath).toFile(), serverList[].class);
			return new JSONArray(readValue);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	private void reschedulerCreate() {
		JobDetail jobName1 = JobBuilder.newJob(RescheduleClass.class).withIdentity("rescheduler").build();
		Trigger trigger = TriggerBuilder.newTrigger().withIdentity("trigger" + "rescheduler")
				.withSchedule(CronScheduleBuilder.cronSchedule("0/1 * * * * ?")).build();
		try {
			scheduler.scheduleJob(jobName1, trigger);
		} catch (SchedulerException e) {
			System.out.println(e);
		}
	}

	private void startTask(JSONObject jsdata) {
		Trigger trigger = TriggerBuilder.newTrigger().withIdentity("trigger" + jsdata.getString("serverName"))
				.withSchedule(CronScheduleBuilder.cronSchedule(jsdata.getString("timeFormat"))).build();
		try {
			JobDetail jobName1 = JobBuilder.newJob(ServerCheck.class).withIdentity(jsdata.getString("serverName")).build();
			scheduler.getContext().put(jsdata.getString("serverName"), jsdata);
			scheduler.scheduleJob(jobName1, trigger);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	static void stopSchedularJob(String jobName) throws Exception {
		JobDetail jobDetail = JobBuilder.newJob(ServerCheck.class).withIdentity(jobName).build();
		scheduler.deleteJob(jobDetail.getKey());
	}
}
