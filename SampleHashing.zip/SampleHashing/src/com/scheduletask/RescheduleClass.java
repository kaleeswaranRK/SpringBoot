package com.scheduletask;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class RescheduleClass implements Job{

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		try {
			new TaskExecuteClass().reschedulerStart();
		} catch (Exception e) {
			System.out.println(e);
		}		
	}

}
