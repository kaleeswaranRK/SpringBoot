package com.couch;

import java.io.IOException;
import java.util.Base64;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class CouchConnection {
	public static void main(String[] args) {
		try {
			CloseableHttpClient httpClient = HttpClients.createDefault();
			String authString = "TestDB" + ":" + "P@ssword";
			String authHeaderValue = "Basic " + Base64.getEncoder().encodeToString(authString.getBytes());
			HttpGet request = new HttpGet("http://172.16.11.16:5984/cxc/_all_docs?include_docs=true");
			request.setHeader("Content-Type", "application/json; charset=utf-8");
			request.setHeader(HttpHeaders.AUTHORIZATION, authHeaderValue);
			HttpResponse response = httpClient.execute(request);
			System.out.println("http");
			System.out.println(response);
			if (response.getStatusLine().getStatusCode() < 300 && response.getStatusLine().getStatusCode() >= 200) {
				HttpEntity entity = response.getEntity();
				System.out.println("status");
				System.out.println(EntityUtils.toString(entity, "UTF-8"));
			} else {
				System.out.println(response.getStatusLine().getStatusCode());
			}
			System.out.println("end");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
