//package com.sanity.property;
//
//import javax.servlet.ServletContextEvent;
//import javax.servlet.ServletContextListener;
//import javax.servlet.annotation.WebListener;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//@WebListener
//public class InitializationClass implements ServletContextListener {
//	@Autowired
//	JsonFileReader jsonRead;
//
//	@Override
//	public void contextInitialized(ServletContextEvent sce) {
//		on_start(sce.getServletContext().getRealPath("/"));
//	}
//
//	private void on_start(String realPath) {
//		realPath = System.getProperty("catalina.base") + "\\Configuration\\SanityAutomation\\config.json";
//		jsonRead.jsonFileToObject(realPath);
//	}
//
//}
