//package com.sanity.property;
//
//import com.sanity.model.FileListClass;
//
//public class Config {
//
//	public static String FILE_PATH = System.getProperty("catalina.base")
//			+ "\\Configuration\\SanityAutomation\\config.json";
//	public static FileListClass FILE_LIST = null;
//}
