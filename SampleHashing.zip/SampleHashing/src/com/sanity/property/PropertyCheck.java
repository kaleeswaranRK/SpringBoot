//package com.sanity.property;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.util.Properties;
//
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class PropertyCheck {
//	long lastModified;
//
//	public Properties propertyLoad(File file) {
//		Properties prop = new Properties();
//		try {
//			prop.load(new FileInputStream(file));
//		} catch (FileNotFoundException e) {
//			System.out.println(e);
//		} catch (IOException e) {
//			System.out.println(e);
//		}
//		return prop;
//
//	}
//	public void lastmodifyIntialization(File file) {
//		
//		if (lastModified == 0) {
//			lastModified = file.lastModified();
//		} 
//	}
//
//	public boolean propertyFileCheck(File file) {
//		if (file.lastModified() != lastModified) {
//			return true;
//		} else {
//			return false;
//		}
//	}
//	
//}
