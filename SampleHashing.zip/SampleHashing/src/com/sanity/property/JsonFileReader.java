//package com.sanity.property;
//
//import java.io.File;
//import java.io.IOException;
//import java.nio.file.Paths;
//
//import javax.servlet.annotation.WebListener;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.fasterxml.jackson.core.exc.StreamReadException;
//import com.fasterxml.jackson.databind.DatabindException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.sanity.model.FileListClass;
//@WebListener
//public class JsonFileReader {
//	@Autowired
//	PropertyCheck property;
//
//	public void jsonFileToObject(String filepath) {
//		File file = new File(filepath);
//		try {
//			property.lastmodifyIntialization(file);
//			if (property.propertyFileCheck(file)||Config.FILE_LIST==null) {
//				ObjectMapper mapper = new ObjectMapper();
//				Config.FILE_LIST = mapper.readValue(Paths.get(filepath).toFile(), FileListClass.class);
//			} else {
//				System.out.println("Already assingned");
//			}
//		} catch (StreamReadException e) {
//			System.out.println(e);
//		} catch (DatabindException e) {
//			System.out.println(e);
//		} catch (IOException e) {
//			System.out.println(e);
//		} catch (Exception e) {
//			System.out.println();
//		}
//	}
//
//}
