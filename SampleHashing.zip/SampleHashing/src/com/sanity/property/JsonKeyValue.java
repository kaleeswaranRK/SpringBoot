//package com.sanity.property;
//
//import org.json.JSONObject;
//import org.springframework.context.annotation.Configuration;
//@Configuration
//public class JsonKeyValue {
//	public String getJsonValue(JSONObject jsonObj, String jsonObj_key) {
//		try {
//
//			if (!jsonObj.has(jsonObj_key)) {
//				return null;
//			} else {
//				return jsonObj.get(jsonObj_key).toString();
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		return null;
//	}
//}