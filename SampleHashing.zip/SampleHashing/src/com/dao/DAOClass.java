package com.dao;

public class DAOClass {
//	public void dbDataInsert(JSONArray databaseData, Connection databaseConnection, String query) {
//		PreparedStatement statement = null;
//		try {
//			statement = databaseConnection.prepareStatement(query);
//			for (int i = 0; i < databaseData.length(); i++) {
//				statement.setString(1, databaseData.getJSONObject(i).getString("fileName"));
//				statement.setString(2, databaseData.getJSONObject(i).getString("downloadStatus"));
//				statement.addBatch();
//			}
//			int[] executeBatch = statement.executeBatch();
//			for (int i = 0; i < executeBatch.length; i++) {
//				if (!(executeBatch[i] >= 0) || !(executeBatch[i] == PreparedStatement.SUCCESS_NO_INFO)) {
//					if (Configurations.CONFIG.has("flatfilePath") && Configurations.CONFIG.has("flatfileName")) {
//						fileoperation.flatFileCreation(Configurations.CONFIG.getString("flatfilePath"),
//								databaseData.getJSONObject(i), Configurations.CONFIG.getString("flatfileName"));
//					}
//				}
//			}
//		} catch (PSQLException e) {
//			logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
//		} catch (Exception e) {
//			logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
//		} finally {
//			try {
//				databaseConnection.close();
//				statement.close();
//			} catch (Exception e) {
//				logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
//			}
//		}
//	}
}
