package com.cxc;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class FileDecryption {
	static String salt = "ulaj6@CB#tv$50p!50c35onsM!";
	static String key = "jcasihkihkhxzkuhousahohkzhxkhoihxlj2yJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4AfiknckjjdljljxzlnokjpoakjbxzicxVPt6a7JTK2o0I42RcBgGQO8DGHt76woiwqjoiwytr46EGWIUJODSJAPIW";

	public static void main(String[] args) throws Exception {

		String salt = "ulaj6@CB#tv$50p!50c35onsM!";
		String key = "jcasihkihkhxzkuhousahohkzhxkhoihxlj2yJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4AfiknckjjdljljxzlnokjpoakjbxzicxVPt6a7JTK2o0I42RcBgGQO8DGHt76woiwqjoiwytr46EGWIUJODSJAPIW";
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		IvParameterSpec ivspec = new IvParameterSpec(iv);
		SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
		KeySpec keySpec = new PBEKeySpec(key.toCharArray(), salt.getBytes(), 65536, 256);
		SecretKey tmp = factory.generateSecret(keySpec);
		SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, secret, ivspec);
		FileInputStream fis = new FileInputStream("D:\\CXC\\audio\\encrypt\\Adventure.wav");
		FileOutputStream fos = new FileOutputStream("D:\\CXC\\audio\\down\\Adventurous.wav");
		byte[] in = new byte[64];
		int read;
		while ((read = fis.read(in)) != -1) {
			byte[] update = cipher.update(in, 0, read);
			if (update != null)
				fos.write(update);
		}
//		byte[] doFinal = cipher.doFinal();
//		if (doFinal != null)

		fis.close();
		fos.flush();
		fos.close();
		System.out.println("File Decrypted.");
	}
}