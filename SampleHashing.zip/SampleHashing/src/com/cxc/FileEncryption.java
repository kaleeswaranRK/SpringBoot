package com.cxc;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class FileEncryption {
	static String salt = "ulaj6@CB#tv$50p!50c35onsM!";
	static String key = "jcasihkihkhxzkuhousahohkzhxkhoihxlj2yJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4AfiknckjjdljljxzlnokjpoakjbxzicxVPt6a7JTK2o0I42RcBgGQO8DGHt76woiwqjoiwytr46EGWIUJODSJAPIW";

	public static void main(String[] args) throws Exception {

		FileInputStream inFile = new FileInputStream("D:\\CXC\\audio\\down\\ff-16b-2c-44100hz.wav");
		FileOutputStream outFile = new FileOutputStream("D:\\CXC\\audio\\encrypt\\Adventure.wav");
		SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
		KeySpec keySpec = new PBEKeySpec(key.toCharArray(), salt.getBytes(), 65536, 256);
		SecretKey secretKey = factory.generateSecret(keySpec);
		SecretKey secret = new SecretKeySpec(secretKey.getEncoded(), "AES");
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		IvParameterSpec ivspec = new IvParameterSpec(iv);
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, secret, ivspec);
		byte[] input = new byte[64];
		int bytesRead;
		while ((bytesRead = inFile.read(input)) != -1) {
			byte[] output = cipher.update(input, 0, bytesRead);
			if (output != null)
				outFile.write(output);
		}
		byte[] output = cipher.doFinal();
		if (output != null)
			outFile.write(output);
		inFile.close();
		outFile.flush();
		outFile.close();

		System.out.println("File Encrypted.");

	}

}