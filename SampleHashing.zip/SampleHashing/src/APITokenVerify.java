import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.*;
import org.junit.jupiter.api.BeforeAll;

import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import static org.junit.Assert.fail;

/**
 * @author user
 */
public class APITokenVerify {

    LocalDateTime ldt;
    JSONObject payload;

    public APITokenVerify() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        ldt = LocalDateTime.now().plusDays(90);
        payload = new JSONObject("{\"sub\":\"1234\",\"aud\":[\"admin\"],"
                + "\"exp\":" + ldt.toEpochSecond(ZoneOffset.UTC) + "}");
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of HMACSHA256 method, of class APITokenGeneration.
     */
    @org.junit.Test
    public void testWithData() {
        //generate JWT
        long exp = LocalDateTime.now().plusDays(90).toEpochSecond(ZoneOffset.UTC);
        String token = new APITokenGeneration("1234", new JSONArray("['admin']"), exp).toString();
        //verify and use
        APITokenGeneration incomingToken;
        System.out.println(token);
        try {
            incomingToken = new APITokenGeneration(token);
            if (incomingToken.isValid()) {
                Assert.assertEquals("1234", incomingToken.getSubject());
                Assert.assertEquals("admin", incomingToken.getAudience().get(0));
            }
        } catch (NoSuchAlgorithmException ex) {
            fail("Invalid Token" + ex.getMessage());
        }

    }

    @org.junit.Test
    public void testWithJson() {

        String token = new APITokenGeneration(payload).toString();
        //verify and use
        APITokenGeneration incomingToken;
        try {
            incomingToken = new APITokenGeneration(token);
            if (incomingToken.isValid()) {
                Assert.assertEquals("1234", incomingToken.getSubject());
                Assert.assertEquals("admin", incomingToken.getAudience().get(0));
            }
        } catch (NoSuchAlgorithmException ex) {
            fail("Invalid Token" + ex.getMessage());
        }
    }

    @org.junit.Test(expected = IllegalArgumentException.class)
    public void testBadHeaderFormat() {

        String token = new APITokenGeneration(payload).toString();
        token = token.replaceAll("\\.", "X");
        //verify and use
        APITokenGeneration incomingToken;
        try {
            incomingToken = new APITokenGeneration(token);
            if (incomingToken.isValid()) {
                Assert.assertEquals("1234", incomingToken.getSubject());
                Assert.assertEquals("admin", incomingToken.getAudience().get(0));
            }
        } catch (NoSuchAlgorithmException ex) {
            fail("Invalid Token" + ex.getMessage());
        }
    }

    @org.junit.Test(expected = NoSuchAlgorithmException.class)
    public void testIncorrectHeader() throws NoSuchAlgorithmException {

        String token = new APITokenGeneration(payload).toString();
        token = token.replaceAll("[^.]", "X");
        //verify and use
        APITokenGeneration incomingToken;
        incomingToken = new APITokenGeneration(token);
        if (incomingToken.isValid()) {
            Assert.assertEquals("1234", incomingToken.getSubject());
            Assert.assertEquals("admin", incomingToken.getAudience().get(0));
        }
    }
}
