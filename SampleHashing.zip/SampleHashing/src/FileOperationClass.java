import java.io.File;

public class FileOperationClass {
	public static void main(String[] args) {
		File file = new File("D:\\CXC\\audio\\down\\ff-16b-2c-44100hz.wav");
		System.out.println(file.toString());
		file.deleteOnExit();
		System.out.println(file.toString());
		System.out.println("hi");
	}
}
