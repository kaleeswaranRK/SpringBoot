
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CryptoPassGenerator extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel inputLabel;
	private JTextArea outputArea;

	public CryptoPassGenerator() {
		// Create components
		JLabel promptLabel = new JLabel("Enter text:");
		JTextField textField = new JTextField(20);
		JButton submitButton = new JButton("Submit");
		inputLabel = new JLabel("");
		outputArea = new JTextArea(10, 50);
		JScrollPane scrollPane = new JScrollPane(outputArea);

		// Set layout and padding
		JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		JPanel inputPanel = new JPanel(new BorderLayout());
		inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		// Add components to input panel
		inputPanel.add(promptLabel, BorderLayout.NORTH);
		inputPanel.add(textField, BorderLayout.CENTER);
		inputPanel.add(submitButton, BorderLayout.EAST);

		// Add components to main panel
		mainPanel.add(inputPanel, BorderLayout.NORTH);
		mainPanel.add(inputLabel, BorderLayout.CENTER);
		mainPanel.add(scrollPane, BorderLayout.SOUTH);

		// Add action listener to submit button
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String inputText = textField.getText();
				inputLabel.setText(inputText);
				outputArea.append(getCipher(inputText) + "\n");
				//outputArea.append(getPlainText(inputText) + "\n");
			}
		});

		// Set up the main frame
		this.getContentPane().add(mainPanel);
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	protected String secretKey = "6gU7jxGdRGDJcisOR435feEvyF57JzDSfgLonlMQkFvZc9Yi0bs0dYzNnR3EZpPqjVPJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4Afi/VPt6a7JTK2o0I42RcBgGQO8DGHt76wXkd+PxxZZPA5YaLPlhXjL70Wdlnqc2Sd+xx0kzcDxTzRedx4VpIe8tEy1sKqFfDfHSZj4qic=";
	protected String salt = "A3k#Gvb6@CB#tv$50p!50c35onsM!";

	private String encrypt(String strToEncrypt, String secret) {
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	private String decrypt(String strToDecrypt, String secret) {
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			String temp = new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
			String returnValue = temp.substring(16, temp.length() - 1);
			return returnValue.substring(0, returnValue.length() - 15);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public String getPlainText(String cipher) {
		if (cipher != null && cipher.trim().length() > 0) {
			return decrypt(cipher, secretKey);
		} else {
			return null;
		}
	}

	public String getCipher(String plainText) {
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		return encrypt(uuid.substring(0, 16).concat(plainText).concat(uuid.substring(16, 32)), secretKey);
	}
	public static void main(String[] args) {
		new CryptoPassGenerator();
	}
}