import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;

public class LogConfigClass {
	public static void main(String[] args) {
		try {
			InputStream inputStream = new FileInputStream("");
			ConfigurationSource source = new ConfigurationSource(inputStream);
			Configurator.initialize(null, source);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
		File file = new File("");
		context.setConfigLocation(file.toURI());
	}
	// System.setProperty("spring.config.location", System.getProperty("user.dir") +"//application.properties");
}
