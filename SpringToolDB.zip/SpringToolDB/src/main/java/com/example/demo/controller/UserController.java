package com.example.demo.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.elib.model.BookProduct;
import com.elib.model.User;
import com.example.demo.dao.Agentdao;
import com.example.demo.model.AgentModel;

@Controller
public class UserController {
	@Autowired
	Agentdao agentdao;
	
	@RequestMapping("index")
	public String userindex() {
		
		return "index.jsp";
	}
	
	@RequestMapping("addUser")
	public String userAdd(AgentModel agent) {
		agentdao.save(agent);
		return "index.jsp";
	}
	@GetMapping("/verify")
	public boolean existUserVerify(@RequestParam Map<String,String> input) {
		try {
			String userid=input.get("userid");
			String password=input.get("password");
			if (userid.length() == 6 && password.length() == 4) {	
				int user = Integer.parseInt(userid);
				int pass = Integer.parseInt(password);
				System.out.println("userid = " + user);
				System.out.println("password = " + pass);
				ResultSet result = userdb.getUserDetail(user, pass);
				if (result.next()) {
					System.out.println("User details verified ok");
					return true;
				} else {
					System.out.println("invalid details");
					return false;
				}

			} else {
				System.out.println("invalid details");
				return false;
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}

		return false;
	}
	@GetMapping(value = "/veri", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> User(@RequestBody User user) {
		try {
			logger.info("user verify API Entry");
			logger.info("userid = " + user.getCustomerId());
			String password = userdb.getPassword(user.getCustomerId());
			if (password == null) {
				logger.info("user verify API Exit");
				return response.generateResponse("No Data found", HttpStatus.NOT_FOUND, null);
				
			} else {
				logger.info("user verify API Exit");
				return response.generateResponse("password data succefully retrived", HttpStatus.OK, password);
			}
		}
		catch (NumberFormatException e) {
			logger.error(e);
			return response.generateResponse(e.toString(), HttpStatus.NOT_FOUND, null);
		} catch (Exception e) {
			logger.error(e);
			return response.generateResponse(e.toString(), HttpStatus.NOT_FOUND, null);
		}
	}
	
	@PostMapping(value = "/carttoremove", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> cartRemove(@RequestParam Map<String,String> input) {
		try {
			if (userdb.cartRemove( input.get("bookName"),Integer.parseInt(input.get("userid")))) {
				logger.info("book removed successfully");
				return response.generateResponse("book removed successfully", HttpStatus.OK, true);
			} else {
				logger.info("book not remove from cart");
				return response.generateResponse("book not remove from cart", HttpStatus.NOT_FOUND, null);
			}
		} catch (Exception e) {
			logger.error(e);
			return response.generateResponse(e.toString(), HttpStatus.NOT_FOUND, null);
		}
	}
	
	@GetMapping("/booksbyauth")
	public List<BookProduct> getProducts(@RequestParam String authorname) {
		try {
			List<BookProduct> books = userdb.getBooksbyAuthor(authorname);
			return books;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
	public List<BookProduct> getBooksbyAuthor(String authorName)  {
		try {
		List<BookProduct> list = new ArrayList<BookProduct>();
		Connection connection = datasource.getDBConnection();
		System.out.println("DB connection");
		PreparedStatement prepareStatement = connection
				.prepareStatement("EXEC KALEESWARAN_GET_BOOKS_BY_AUTHOR @name=");
		prepareStatement.setString(1,authorName);
		ResultSet result = prepareStatement.executeQuery();
		while (result.next()) {
		BookProduct book=new BookProduct(result.getInt("BOOK_ID"), result.getString("BOOK_NAME"), result.getString("AUTHOR_NAME"), result.getInt("BOOK_QUANTITY"), result.getDouble("BOOK_PRICE"));
		list.add(book);
		}
		return list;
		}
		catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
	
	public ResultSet getUserId(int userid) {
		try {
			logger.info("getUser Id method Entry");
			Connection connection = datasource.getDBConnection();
			logger.info("DB connection Establised");
			PreparedStatement prepareStatement = connection.prepareStatement("EXEC KALEESWARAN_GET_PASSWORD @id =?");
			prepareStatement.setInt(1, userid);
			ResultSet resultSet = prepareStatement.executeQuery();
			logger.info("query executed");
			logger.info("getUser Id method Exit");
			return resultSet;
		} catch (SQLException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}
	public ResultSet checkUserId(int userid) {

		try {
			logger.info("check user id method Entry");
			Connection connection = datasource.getDBConnection();
			logger.info("DB connection Establised");
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement("EXEC KALEESWARAN_VERIFY_ID @id=?");
			prepareStatement.setInt(1, userid);
			ResultSet resultSet = prepareStatement.executeQuery();
			logger.info("query executed");
			logger.info("check user id method Exit");
			return resultSet;
		} catch (SQLException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}
	
	public boolean InsertUserDetail(int userid, String password) {

		try {
			logger.info("Insert user detail method Entry");
			Connection connection = datasource.getDBConnection();
			logger.info("DB connection Establised");
			PreparedStatement prepareStatement = connection
					.prepareStatement("EXEC KALEESWARAN_ADD_USER @id =?,@pass=?");
			prepareStatement.setInt(1, userid);
			prepareStatement.setString(2, password);
			if (prepareStatement.executeUpdate() < 1) {
				return false;
			} else {
				logger.info("Insert user detail method Exit");
				logger.info("query executed");
				return true;
			}
		} catch (SQLException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		return false;

	}
	@PostMapping(value = "/addtocart", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> addToCart(@RequestParam Map<String, String> input) {
		try {
			logger.info("add to cart API Entry");
			boolean cartAdd = userdb.cartAddCount(input.get("bookName"), Integer.parseInt(input.get("bookQuantity")), Double.parseDouble(input.get("bookPrice")), Integer.parseInt(input.get("userid")));
				if (cartAdd) {
					logger.info("book added successfully");
					logger.info("add to cart API Exit");
					return response.generateResponse("book added successfully", HttpStatus.OK, true);

				} else {
					logger.info("book not added to cart");
					return response.generateResponse("book not added to cart", HttpStatus.NOT_FOUND, null);
				}
			}
		 catch (Exception e) {
			logger.error(e);
			return response.generateResponse(e.toString(), HttpStatus.NOT_FOUND, null);
		}
	}
	
	
	@PostMapping(value = "/addnewuser", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> addNewUser(@RequestBody User user) {
		try {
			int userid = user.getCustomerId();
			String password = user.getCustomerPassword();
			if (String.valueOf(userid).length() == 6) {
				ResultSet resultSet = userdb.checkUserId(userid);
				if (resultSet.next()) {
					System.out.println("Already Exist");
					return response.generateResponse("Already Exist user", HttpStatus.NOT_FOUND, null);
				} else {
					int insertCount = userdb.InsertUserDetail(userid, password);
					if (insertCount < 1) {
						System.out.println("User Details not added");
						return response.generateResponse("user detail not added", HttpStatus.NOT_FOUND, null);
					} else {
						System.out.println("user Details added successfully");
						return response.generateResponse("user detail added succefully", HttpStatus.OK, insertCount);

					}
				}
			} else {
				System.out.println("invalid Credentials");
				return response.generateResponse("invalid Credentials", HttpStatus.NOT_FOUND, null);
			}
		} catch (NumberFormatException e) {
			return response.generateResponse(e.toString(), HttpStatus.NOT_FOUND, null);

		} catch (Exception e) {
			return response.generateResponse(e.toString(), HttpStatus.NOT_FOUND, null);

		}
	}
}
