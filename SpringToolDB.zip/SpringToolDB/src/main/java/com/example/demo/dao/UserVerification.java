package com.example.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elib.dao.Userdbperations;
import com.elib.model.Category;

@Service
public class UserVerification {
	

	public boolean verifyUser(String userid, String password) {
		if (userid.length() == 6 && password.length() == 4) {
			int user = Integer.parseInt(userid);
			int pass = Integer.parseInt(password);
			System.out.println("userid = " + user);
			System.out.println("password = " + pass);
			ResultSet result = userdb.getUserDetail(user, pass);
			if (result.next()) {
				System.out.println("User details verified ok");
				return true;
			} else {
				System.out.println("invalid details");
				return false;
			}

		} else {
			System.out.println("invalid details");
			return false;
		}
	} catch (Exception e) {
		System.out.println(e);
	}

	return false;
	}

	public boolean addUser(String userid, String password) {
		
		try {
			if (userid.length() == 6 && password.length() == 4) {
				int user = Integer.parseInt(userid);
				int pass = Integer.parseInt(password);
				ResultSet resultSet = userdb.checkUserId(user);
			if (resultSet.next()) {
				System.out.println("Already Exist");
				return false;
			}
			else {
				int insertCount = userdb.InsertUserDetail(user, pass);
				if (insertCount<1) {
					System.out.println("User Details not added");
					return false;
				}
				else {
					System.out.println("user Details added successfully");
					return true;
				}
			}
			}
			else {
				System.out.println("invalid Credentials");
				return false;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}public Category getCategory(int categoryid) {
		try {
			logger.info("getCategory method Entry");
			Connection connection = datasource.getDBConnection();
			logger.info("DB connection Establised");
			PreparedStatement prepareStatement = connection.prepareStatement("EXEC KALEESWARAN_GET_CATEGORY @id=?");
			prepareStatement.setInt(1, categoryid);
			ResultSet categoryresult = prepareStatement.executeQuery();
			if (categoryresult.next()) {
				Category category = new Category(categoryresult.getInt("CATEGORY_ID"),
						categoryresult.getString("CATEGORY_NAME"));
				logger.info("getCategory method Exit");
				return category;
			} else {
				return null;
			}

		} catch (SQLException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}


}
