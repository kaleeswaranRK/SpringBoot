package hasing;
@Configuration
@PropertySource(value = "file:C:\\Users\\User\\Desktop\\Kaleeswaran\\ElibraryFiles\\prop.properties")
public class DataSourceProperty {
	@Autowired
	Environment env;

	static BasicDataSource dataSource;
	static long lastModified;
	static Logger logger = LogManager.getLogger("ElibraryFlowProject");
	static File file = new File("file:C:\\Users\\User\\Desktop\\Kaleeswaran\\ElibraryFiles\\prop.properties");

	public BasicDataSource getDataSource() {
		try {
			if (dataSource == null) {
				BasicDataSource ds = new BasicDataSource();
				ds.setDriverClassName(env.getProperty("driverjdbc"));
				ds.setUrl(env.getProperty("connectionUrl"));
				ds.setUsername(env.getProperty("dbusername"));
				ds.setPassword(env.getProperty("dbpassword"));
				logger.info("driverjdbc = " + ds.getDriverClassName() + "  connectionUrl = " + ds.getUrl()
						+ "  dbusername = " + ds.getUsername() + "  dbpassword = " + ds.getPassword());
				ds.setMinIdle(5);
				ds.setMaxIdle(10);
				ds.setMaxTotal(25);
				dataSource = ds;
				return dataSource;
			} else {
				logger.info("data source already assigned");
				return dataSource;
			}

		} catch (Exception e) {
			logger.error(e);
		}
		return dataSource;
	}

	public Connection getDBConnection() {
		try {
			lastmodifyIntialization();
			if (propertyFileCheck()) {
				Properties prop=new Properties();
				prop.load(new FileInputStream(file));
			}
			return getDataSource().getConnection();
		} catch (SQLException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}

	public void lastmodifyIntialization() {
		if (lastModified == 0) {
			lastModified= file.lastModified();
		} 
		else {
			logger.info("last Modified"+lastModified);
		}
	}

	public boolean propertyFileCheck() {
		if (file.lastModified() != lastModified) {
			return true;
		} else {
			return false;
		}
	}
}