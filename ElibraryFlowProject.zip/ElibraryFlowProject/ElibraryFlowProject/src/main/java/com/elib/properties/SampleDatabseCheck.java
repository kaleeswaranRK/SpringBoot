package com.elib.properties;

import java.sql.Connection;
import java.sql.DriverManager;

public class SampleDatabseCheck {
	public static void main(String[] args) {
		try {
			String connectionDriveClassName = null;
			String connectionPrefix = null;
			String connectionString = null;
//			String hostName = "192.168.168.12";
//			String port = "1433";
//			String schema = "DNATA";
			String hostName = "172.16.11.52";
			String port = "5432";
			String schema = "freeswitch";
			
			switch ("MYSQL") {
			case "MSSQL":
				connectionDriveClassName = ApplicationConstants.MSSQL_DRIVER;
				connectionPrefix = ApplicationConstants.MSSQL_PREFIX;
				connectionString = connectionPrefix.concat(hostName).concat(":").concat(port).concat(";databaseName=")
						.concat(schema).concat(";encrypt=true;trustServerCertificate=true;");
				break;
			case "MYSQL":
				connectionDriveClassName = ApplicationConstants.MYSQL_DRIVER;
				connectionPrefix = ApplicationConstants.MYSQL_PREFIX;
				connectionString = connectionPrefix.concat(hostName).concat(":").concat(port).concat("/")
						.concat(schema);
				break;
			case "POSTGRES":
				connectionDriveClassName = ApplicationConstants.POSTGRES_DRIVER;
				connectionPrefix = ApplicationConstants.POSTGRES_PREFIX;
				connectionString = connectionPrefix.concat(hostName).concat(":").concat(port).concat("/")
						.concat(schema);
				break;
			case "ORACLE":
				connectionDriveClassName = ApplicationConstants.ORACLE_DRIVER;
				connectionPrefix = ApplicationConstants.ORACLE_PREFIX;
				connectionString = connectionPrefix.concat(hostName).concat(":").concat(port).concat("/")
						.concat(schema);
				break;
			default:
				connectionDriveClassName = ApplicationConstants.MSSQL_DRIVER;
				connectionPrefix = ApplicationConstants.MSSQL_PREFIX;
				connectionString = connectionPrefix.concat(hostName).concat(":").concat(port).concat(";databaseName=")
						.concat(schema);
			}
			Class.forName(connectionDriveClassName);
			try {
				DriverManager.setLoginTimeout(10);
//				Connection connection = DriverManager.getConnection(connectionString, "sa", "P@ssw0rd");
				Connection connection = DriverManager.getConnection(connectionString, "testuser", "testuser");
				System.out.println("connection created");
				System.out.println(connection.toString());
				System.out.println("end");
			} catch (Exception e) {
				System.out.println(e);
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
