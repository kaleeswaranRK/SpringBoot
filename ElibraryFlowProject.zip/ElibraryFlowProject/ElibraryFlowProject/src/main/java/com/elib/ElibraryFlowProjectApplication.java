
package com.elib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Elibrary", version = "0.0"))
public class ElibraryFlowProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElibraryFlowProjectApplication.class, args);

	}

}
