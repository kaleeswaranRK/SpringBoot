package com.elib.properties;

public class ApplicationConstants {
	
	public static final String JOBS_FILE_PATH =  System.getProperty("catalina.base").concat("\\ApplicationConfiguration\\ServerSentinel\\Jobs.json");
	public static final String CONFIG_FILE_PATH =  System.getProperty("catalina.base").concat("\\ApplicationConfiguration\\ServerSentinel\\Config.json");
	public static final String LOG_CONFIG_FILE_PATH =  System.getProperty("catalina.base").concat("\\ApplicationConfiguration\\ServerSentinel\\logConfig.xml");
	public static final String LOCAL_DATABASE_PATH = "jdbc:h2:".concat(System.getProperty("catalina.base").concat("\\ApplicationConfiguration\\ServerSentinel\\db;AUTO_SERVER=TRUE"));
	public static final String LOCAL_DATABASE_USER_NAME = "sentinel";
	
	public static final String MSSQL_PREFIX = "jdbc:sqlserver://";
	public static final String MYSQL_PREFIX = "jdbc:mysql://";
	public static final String POSTGRES_PREFIX = "jdbc:postgresql://";
	public static final String ORACLE_PREFIX = "jdbc:oracle:thin:@";

	public static final String MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static final String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String POSTGRES_DRIVER = "org.postgresql.Driver";
	public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";


}
